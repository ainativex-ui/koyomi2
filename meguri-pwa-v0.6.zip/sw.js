/* 巡(めぐり) Service Worker v0.4.0
 * 方針: アプリ殻はプリキャッシュ+stale-while-revalidate(表示は即・裏で更新)。
 * フォント等のクロスオリジンは実行時キャッシュ。オフラインでも全機能動作。
 * 更新: CACHE名を変えて配備すると旧キャッシュは自動掃除される。 */
"use strict";
var CACHE = "meguri-v0.6.0";
var CORE = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-maskable-512.png",
  "./icons/apple-touch-icon.png",
  "./icons/favicon-32.png"
];

self.addEventListener("install", function (e) {
  e.waitUntil(
    caches.open(CACHE).then(function (c) { return c.addAll(CORE); }).then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener("activate", function (e) {
  e.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.map(function (k) { if (k !== CACHE) return caches.delete(k); }));
    }).then(function () { return self.clients.claim(); })
  );
});

self.addEventListener("fetch", function (e) {
  var req = e.request;
  if (req.method !== "GET") return;
  e.respondWith(
    caches.open(CACHE).then(function (c) {
      return c.match(req, { ignoreSearch: req.mode === "navigate" }).then(function (hit) {
        var net = fetch(req).then(function (res) {
          if (res && (res.status === 200 || res.type === "opaque")) {
            try { c.put(req, res.clone()); } catch (err) {}
          }
          return res;
        }).catch(function () {
          // オフライン: ナビゲーションはアプリ殻へフォールバック
          if (req.mode === "navigate") return c.match("./index.html");
          return hit;
        });
        return hit || net;
      });
    })
  );
});
